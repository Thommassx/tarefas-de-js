// Tabuada Simples
let numero = 5;
for (let i = 1; i <= 10; i++) {
  console.log(numero + " x " + i + " = " + (numero * i));
}

// Contagem de 1 a 10
for (let i = 1; i <= 10; i++) {
  console.log(i);
}

// Contador de pares de 0 a 20
for (let i = 0; i <= 20; i++) {
  if (i % 2 === 0) {
    console.log(i);
  }
}

// Contagem regressiva de 10 até 1
for (let i = 10; i >= 1; i--) {
  console.log(i);
}
console.log("Lançamento!");

// Soma até 100
let soma = 0;
let num = 1;
while (soma <= 100) {
  soma += num;
  num++;
}
console.log("Soma final: " + soma);
console.log("Último número somado: " + (num - 1));

// Contagem de ímpares de 1 a 15
let i = 1;
while (i <= 15) {
  if (i % 2 !== 0) {
    console.log(i);
  }
  i++;
}

// Contador de Passos
let passos = 0;
while (passos < 10) {
  passos++;
  console.log("Passo " + passos);
}
console.log("Chegou ao destino!");

// Adivinhe o Número
const numeroSecreto = 7;
let tentativa = 0;

while (tentativa !== numeroSecreto) {
  tentativa = Math.floor(Math.random() * 10) + 1; 
  console.log("Tentativa: " + tentativa);
}
console.log("Acertou o número secreto!");