// Voto Consciente
let idade = 17;
if (idade >= 16) {
  console.log("Pode votar");
} else {
  console.log("Não pode votar");
}

// Análise Numérica
let numero = -5;
if (numero > 0) {
  console.log("Positivo");
} else if (numero < 0) {
  console.log("Negativo");
} else {
  console.log("Zero");
}

// Acesso Restrito
let usuario = "admin";
let senha = "1234";
let userDigitado = "admin";
let senhaDigitada = "1234";

if (userDigitado === usuario && senhaDigitada === senha) {
  console.log("Login bem-sucedido");
} else {
  console.log("Usuário ou senha incorretos");
}

// Calendário Automatizado
let dia = 3;
let nomeDia;

if (dia === 1) nomeDia = "Domingo";
else if (dia === 2) nomeDia = "Segunda";
else if (dia === 3) nomeDia = "Terça";
else if (dia === 4) nomeDia = "Quarta";
else if (dia === 5) nomeDia = "Quinta";
else if (dia === 6) nomeDia = "Sexta";
else if (dia === 7) nomeDia = "Sábado";
else nomeDia = "Número inválido";

console.log(nomeDia);

// Classificador de Números
let n = 10;
if (n % 2 === 0) {
  console.log("Par");
} else {
  console.log("Ímpar");
}

// Sistema de Notas
let nota = 85;
if (nota >= 90) console.log("A");
else if (nota >= 80) console.log("B");
else if (nota >= 70) console.log("C");
else if (nota >= 60) console.log("D");
else console.log("F");

// Promoção Inteligente
let valor = 120;
let valorFinal;

if (valor >= 100) {
  valorFinal = valor * 0.9;
  console.log("Desconto aplicado. Total: R$" + valorFinal.toFixed(2));
} else {
  console.log("Sem desconto. Total: R$" + valor.toFixed(2));
}

// Identificador de Triângulo
let a = 5, b = 5, c = 5;

if (a + b > c && a + c > b && b + c > a) {
  if (a === b && b === c) {
    console.log("Equilátero");
  } else if (a === b || a === c || b === c) {
    console.log("Isósceles");
  } else {
    console.log("Escaleno");
  }
} else {
  console.log("Não forma um triângulo");
}

// Classificação Etária
let idadePessoa = 45;

if (idadePessoa < 12) console.log("Criança");
else if (idadePessoa < 18) console.log("Adolescente");
else if (idadePessoa < 60) console.log("Adulto");
else console.log("Idoso");

// Mini Calculadora
let num1 = 10;
let num2 = 0;
let operador = "/";

let resultado;

if (operador === "+") resultado = num1 + num2;
else if (operador === "-") resultado = num1 - num2;
else if (operador === "*") resultado = num1 * num2;
else if (operador === "/") {
  if (num2 === 0) console.log("Erro: divisão por zero");
  else resultado = num1 / num2;
} else {
  console.log("Operador inválido");
}

if (resultado !== undefined) console.log("Resultado: " + resultado);
