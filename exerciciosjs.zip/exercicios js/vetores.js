// Somar todos os elementos
let numeros = [2, 4, 6, 8, 10];
let soma = 0;
for (let i = 0; i < numeros.length; i++) {
  soma += numeros[i];
}
console.log("Soma total:", soma);

// Encontrar o maior número
let valores = [3, 17, 9, 22, 5];
let maior = valores[0];
for (let i = 1; i < valores.length; i++) {
  if (valores[i] > maior) {
    maior = valores[i];
  }
}
console.log("Maior número:", maior);

// Inverter a ordem
let original = [1, 2, 3, 4, 5];
let invertido = [];
for (let i = original.length - 1; i >= 0; i--) {
  invertido.push(original[i]);
}
console.log("Ordem invertida:", invertido);

// Contar números pares
let lista = [1, 2, 3, 4, 5, 6, 7, 8];
let pares = 0;
for (let i = 0; i < lista.length; i++) {
  if (lista[i] % 2 === 0) {
    pares++;
  }
}
console.log("Quantidade de pares:", pares);

// Unir dois vetores
let vetor1 = [1, 2, 3];
let vetor2 = [4, 5, 6];
let combinado = [];
for (let i = 0; i < vetor1.length; i++) {
  combinado.push(vetor1[i]);
}
for (let i = 0; i < vetor2.length; i++) {
  combinado.push(vetor2[i]);
}
console.log("Vetores unidos:", combinado);
